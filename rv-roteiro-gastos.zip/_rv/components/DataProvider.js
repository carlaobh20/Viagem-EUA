'use client';
import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { supabase } from '../lib/supabaseClient';
import { hojeLocal } from '../lib/format';

// Busca uma foto de capa da cidade pra viagens nacionais, usando a API pública
// e gratuita da Wikipedia (sem chave, sem custo). Best-effort: qualquer falha
// (cidade sem verbete, sem internet, timeout) simplesmente retorna null e a
// viagem fica sem foto de capa — igual ao comportamento antes dessa função
// existir. Nunca deve travar nem quebrar a criação da viagem.
async function buscarFotoCidade(nomeCidade) {
  const nome = (nomeCidade || '').trim();
  if (!nome || typeof fetch === 'undefined') return null;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    const res = await fetch(`https://pt.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(nome)}`, {
      headers: { Accept: 'application/json' }, signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!res.ok) return null;
    const j = await res.json();
    return (j.thumbnail && j.thumbnail.source) || (j.originalimage && j.originalimage.source) || null;
  } catch (e) {
    return null;
  }
}

const DataContext = createContext(null);
export const useData = () => useContext(DataContext);
export function DataProvider({ session, children }) {
  const [perfil, setPerfil] = useState(null);
  const [viagem, setViagem] = useState(null);
  const [viagens, setViagens] = useState([]);
  const [perfis, setPerfis] = useState([]);
  const [pontos, setPontos] = useState([]);
  const [gastos, setGastos] = useState([]);
  const [divisoes, setDivisoes] = useState([]);
  const [gastoVistoPor, setGastoVistoPor] = useState([]);
  const [acertos, setAcertos] = useState([]);
  const [loginsApp, setLoginsApp] = useState([]);
  const [registrosKm, setRegistrosKm] = useState([]);
  const [checklist, setChecklist] = useState([]);
  const [guardados, setGuardados] = useState([]);
  const [lugares, setLugares] = useState([]);
  const [passagens, setPassagens] = useState([]);
  const [documentos, setDocumentos] = useState([]);
  const [reservasRv, setReservasRv] = useState([]);
  const [appsInstalar, setAppsInstalar] = useState([]);
  const [perguntasImigracao, setPerguntasImigracao] = useState([]);
  const [appsMarcados, setAppsMarcados] = useState([]);
  const [diario, setDiario] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState(null);
  const [gastoEditando, setGastoEditando] = useState(null);
  const [precisaNome, setPrecisaNome] = useState(false);

  const carregar = useCallback(async () => {
    try {
    const { data: { session: sess } } = await supabase.auth.getSession();
    const authUser = sess?.user || session.user;
    const uid = authUser.id;
    // viagens das quais sou membro
    const { data: ms } = await supabase.from('viagem_membros').select('viagem_id').eq('user_id', uid);
    const vids = (ms || []).map((m) => m.viagem_id);
    let vs = [];
    if (vids.length) { const r = await supabase.from('viagens').select('*').in('id', vids).order('criado_em'); vs = r.data || []; }
    setViagens(vs);
    // nome de exibição agora é global (auth user_metadata), não preso a uma viagem
    const metaNome = (authUser.user_metadata?.nome || '').trim();
    const savedId = (typeof window !== 'undefined' && window.localStorage.getItem('viagemAtiva')) || null;
    const v = vs.find((x) => x.id === savedId) || vs[0] || null;
    setViagem(v);
    setErro(null);
    // sem nenhuma viagem: não cria nada. Pede o nome se ainda não escolheu; o app abre no lobby de viagens.
    if (!v) { setPerfil(null); setPrecisaNome(!metaNome); setCarregando(false); return; }
    // garante o meu perfil nesta viagem — pega TODOS os meus e usa o mais antigo.
    // (Nunca usar .maybeSingle() aqui: se houver duplicata ele retorna null e o código
    //  reinsere outro perfil; com a subscription realtime de 'perfis' isso vira loop infinito.)
    let { data: meus } = await supabase.from('perfis').select('*').eq('user_id', uid).eq('viagem_id', v.id).order('criado_em');
    meus = meus || [];
    let meu = meus[0] || null;
    if (!meu) {
      const nome = metaNome || authUser.email.split('@')[0];
      const rp = await supabase.from('perfis').insert({ user_id: uid, nome, cor: corAleatoria(), viagem_id: v.id, nome_definido: !!metaNome }).select().single();
      meu = rp.data;
    } else if (meus.length > 1) {
      // Conserta o estrago do bug antigo: já existem vários perfis meus nesta viagem.
      // Mantém o mais antigo, reaponta o que estiver em uso e apaga o resto.
      try {
        const manter = meu.id;
        const dupIds = meus.slice(1).map((p) => p.id);
        await supabase.from('gastos').update({ pago_por: manter }).in('pago_por', dupIds);
        await supabase.from('gasto_divisao').update({ perfil_id: manter }).in('perfil_id', dupIds);
        await supabase.from('acertos').update({ de: manter }).in('de', dupIds);
        await supabase.from('acertos').update({ para: manter }).in('para', dupIds);
        await supabase.from('perfis').delete().in('id', dupIds);
      } catch (limpezaErro) { /* se falhar, segue com o perfil mais antigo mesmo */ }
    }
    setPerfil(meu);
    // pede o nome só se ainda não houver nome global. usuário antigo (já tinha nome na viagem): copia pro global e não pergunta de novo.
    let precisa = !metaNome;
    if (precisa && meu && meu.nome_definido && meu.nome) { await supabase.auth.updateUser({ data: { nome: meu.nome } }); precisa = false; }
    setPrecisaNome(precisa);
    // Tudo o que depende só de v.id/uid vai numa leva paralela (antes eram ~11
    // consultas em fila, o que deixava a tela "Carregando a viagem…" travada).
    const [
      { data: ps }, { data: pts }, { data: gs }, { data: acs }, { data: rk }, { data: ck },
      { data: gd }, { data: lg }, { data: ai }, { data: pi }, { data: am }, { data: dr }, { data: pg }, { data: dc }, { data: da }, { data: rv }, { data: lap },
    ] = await Promise.all([
      supabase.from('perfis').select('*').eq('viagem_id', v.id).order('criado_em'),
      supabase.from('pontos_roteiro').select('*').eq('viagem_id', v.id).order('ordem'),
      supabase.from('gastos').select('*').eq('viagem_id', v.id).order('data', { ascending: false }),
      supabase.from('acertos').select('*').eq('viagem_id', v.id).order('criado_em', { ascending: false }),
      supabase.from('registros_km').select('*').eq('viagem_id', v.id).order('data', { ascending: false }),
      supabase.from('checklist_itens').select('*').eq('viagem_id', v.id).order('ordem'),
      supabase.from('guardados').select('*').eq('viagem_id', v.id).eq('user_id', uid).order('criado_em'),
      supabase.from('lugares').select('*').eq('viagem_id', v.id).order('criado_em'),
      supabase.from('apps_instalar').select('*').eq('viagem_id', v.id).order('criado_em'),
      supabase.from('perguntas_imigracao').select('*').eq('viagem_id', v.id).order('ordem'),
      supabase.from('apps_marcados').select('*').eq('viagem_id', v.id).eq('user_id', uid),
      supabase.from('diario_entradas').select('*').eq('viagem_id', v.id).order('data').order('criado_em'),
      supabase.from('passagens').select('*').eq('viagem_id', v.id).order('data').order('hora').order('criado_em'),
      supabase.from('documentos').select('*').eq('viagem_id', v.id).order('categoria').order('criado_em'),
      supabase.from('documento_arquivos').select('*').eq('viagem_id', v.id).order('ordem'),
      supabase.from('reservas_rv').select('*').eq('viagem_id', v.id).order('checkin').order('criado_em'),
      supabase.from('logins_app').select('*').eq('viagem_id', v.id).order('app'),
    ]);
    setPerfis(ps || []); setPontos(pts || []); setGastos(gs || []); setAcertos(acs || []); setRegistrosKm(rk || []); setChecklist(ck || []);
    setGuardados(gd || []); setLugares(lg || []); setAppsInstalar(ai || []); setPerguntasImigracao(pi || []); setAppsMarcados(am || []);
    setDiario(dr || []); setPassagens(pg || []); setDocumentos((dc || []).map((d) => ({ ...d, arquivos: (da || []).filter((x) => x.documento_id === d.id) })));
    setReservasRv(rv || []);
    setLoginsApp(lap || []);
    // divisões e "visto por" dependem dos ids dos gastos, então vão numa segunda leva (também paralela)
    const ids = (gs || []).map((g) => g.id);
    if (ids.length) {
      const [{ data: dv }, { data: vp }] = await Promise.all([
        supabase.from('gasto_divisao').select('*').in('gasto_id', ids),
        supabase.from('gasto_visto_por').select('*').in('gasto_id', ids),
      ]);
      setDivisoes(dv || []); setGastoVistoPor(vp || []);
    } else { setDivisoes([]); setGastoVistoPor([]); }
    setErro(null);
    } catch (e) { setErro((e && e.message) || 'Falha ao carregar a viagem.'); }
    finally { setCarregando(false); }
  }, [session]);

  useEffect(() => {
    carregar();
    let t;
    const deb = () => { clearTimeout(t); t = setTimeout(() => carregar(), 400); };
    const canal = supabase.channel('viagem-mudancas')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'gastos' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'gasto_divisao' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'viagens' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'perfis' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'acertos' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'registros_km' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'checklist_itens' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'dicas' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'diario_entradas' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'passagens' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'documentos' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'logins_app' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'documento_arquivos' }, deb)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'reservas_rv' }, deb)
      .subscribe();
    return () => { clearTimeout(t); supabase.removeChannel(canal); };
  }, [carregar]);

  async function subirRecibo(file) {
    const path = `${viagem.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.jpg`;
    const { error } = await supabase.storage.from('recibos').upload(path, file, { contentType: 'image/jpeg', upsert: false });
    if (error) return null;
    return path; // guarda o caminho; a URL é assinada na hora de ver
  }

  async function urlRecibo(ref) {
    if (!ref) return null;
    if (ref.startsWith('http')) return ref; // recibos antigos (URL pública)
    const { data } = await supabase.storage.from('recibos').createSignedUrl(ref, 3600);
    return (data && data.signedUrl) || null;
  }

  async function salvarGasto({ descricao, valor, moeda, categoria, pagoPor, pontoId, data, participantes, reciboFile, privado, compartilhadoCom }) {
    let recibo_url = null;
    if (reciboFile) { recibo_url = await subirRecibo(reciboFile); if (!recibo_url) throw new Error('Não consegui enviar a foto do comprovante. Confere a internet e tenta de novo.'); }
    const { data: novo, error } = await supabase.from('gastos').insert({
      viagem_id: viagem.id, descricao, valor, moeda, categoria, pago_por: pagoPor, ponto_id: pontoId || null, data, recibo_url, privado: !!privado, user_id: session.user.id,
    }).select().single();
    if (error) throw error;
    const linhas = participantes.map((p) => ({ gasto_id: novo.id, perfil_id: p.id, partes: p.partes }));
    await supabase.from('gasto_divisao').insert(linhas);
    if (privado && compartilhadoCom && compartilhadoCom.length) {
      await supabase.from('gasto_visto_por').insert(compartilhadoCom.map((perfilId) => ({ gasto_id: novo.id, perfil_id: perfilId })));
    }
    await carregar();
  }

  async function atualizarGasto({ id, descricao, valor, moeda, categoria, pagoPor, pontoId, data, participantes, reciboFile, reciboUrlAtual, removerRecibo, privado, compartilhadoCom, userIdAtual }) {
    let recibo_url = removerRecibo ? null : (reciboUrlAtual || null);
    if (reciboFile) { const novo = await subirRecibo(reciboFile); if (!novo) throw new Error('Não consegui enviar a foto do comprovante. Confere a internet e tenta de novo.'); recibo_url = novo; }
    // Gastos antigos foram criados antes da coluna user_id existir e ficaram com user_id nulo.
    // Se houver uma política de RLS de UPDATE exigindo user_id = auth.uid(), editá-los falha.
    // Preenchemos o user_id com o do editor quando estiver vazio (não rouba a autoria de quem já tem).
    const patch = { descricao, valor, moeda, categoria, pago_por: pagoPor, ponto_id: pontoId || null, data, recibo_url, privado: !!privado };
    if (!userIdAtual) patch.user_id = session.user.id;
    const { error } = await supabase.from('gastos').update(patch).eq('id', id);
    if (error) throw error;
    await supabase.from('gasto_divisao').delete().eq('gasto_id', id);
    const linhas = participantes.map((p) => ({ gasto_id: id, perfil_id: p.id, partes: p.partes }));
    await supabase.from('gasto_divisao').insert(linhas);
    await supabase.from('gasto_visto_por').delete().eq('gasto_id', id);
    if (privado && compartilhadoCom && compartilhadoCom.length) {
      await supabase.from('gasto_visto_por').insert(compartilhadoCom.map((perfilId) => ({ gasto_id: id, perfil_id: perfilId })));
    }
    await carregar();
  }

  async function registrarAcerto({ de, para, valor, moeda }) {
    await supabase.from('acertos').insert({ viagem_id: viagem.id, de, para, valor, moeda: moeda || 'BRL', data: hojeLocal() });
    await carregar();
  }
  async function removerAcerto(id) { await supabase.from('acertos').delete().eq('id', id); await carregar(); }

  async function adicionarPessoa(nome) { await supabase.from('perfis').insert({ nome: nome.trim(), cor: corAleatoria(), viagem_id: viagem.id, nome_definido: true }); await carregar(); }
  async function atualizarNomePessoa(id, nome) { await supabase.from('perfis').update({ nome: nome.trim() }).eq('id', id); await carregar(); }
  async function removerPessoa(id) { const { error } = await supabase.from('perfis').delete().eq('id', id); await carregar(); return error; }
  async function atualizarCotacao(cotacao) { await supabase.from('viagens').update({ cotacao_usd: cotacao }).eq('id', viagem.id); await carregar(); }
  async function atualizarOrcamento(orcamento) { await supabase.from('viagens').update({ orcamento_brl: orcamento }).eq('id', viagem.id); await carregar(); }
  async function removerGasto(id) { await supabase.from('gastos').delete().eq('id', id); await carregar(); }
  async function adicionarKm({ km, valorOrigem, unidade, data, origem, destino, nota }) { await supabase.from('registros_km').insert({ viagem_id: viagem.id, km, valor_origem: valorOrigem, unidade, data: data || null, origem: origem || null, destino: destino || null, nota: nota || null }); await carregar(); }
  async function removerKm(id) { await supabase.from('registros_km').delete().eq('id', id); await carregar(); }
  async function adicionarChecklist({ texto, tema, prazo, ordem, moeda }) { await supabase.from('checklist_itens').insert({ viagem_id: viagem.id, user_id: session.user.id, texto, tema: tema || 'Geral', prazo: prazo || null, ordem: ordem || 0, moeda: moeda === 'USD' ? 'USD' : 'BRL' }); await carregar(); }
  async function alternarChecklist(id, feito) { await supabase.from('checklist_itens').update({ feito }).eq('id', id); await carregar(); }
  async function definirValorCompra(id, feito, valor) {
    const v = (valor === '' || valor == null || isNaN(valor)) ? null : Number(valor);
    const { error } = await supabase.from('checklist_itens').update({ feito, valor: v }).eq('id', id);
    if (error) { await supabase.from('checklist_itens').update({ feito }).eq('id', id); } // coluna 'valor' ainda não existe: marca mesmo assim
    await carregar();
  }
  // Preço do item na lista de Compras — independente de já ter sido comprado ou não.
  async function definirValorItem(id, valor, moeda) {
    const v = (valor === '' || valor == null || isNaN(valor)) ? null : Number(valor);
    const patch = { valor: v };
    if (moeda === 'USD' || moeda === 'BRL') patch.moeda = moeda;
    const { error } = await supabase.from('checklist_itens').update(patch).eq('id', id);
    if (error) { console.warn('Não foi possível salvar o valor (coluna "valor" pode não existir ainda em checklist_itens).', error); }
    await carregar();
  }
  async function editarChecklist(id, texto) { await supabase.from('checklist_itens').update({ texto }).eq('id', id); await carregar(); }
  async function removerChecklist(id) { await supabase.from('checklist_itens').delete().eq('id', id); await carregar(); }
  async function semearChecklist(itens) { if (!itens || !itens.length) return; await supabase.from('checklist_itens').insert(itens.map((it) => ({ ...it, viagem_id: viagem.id, user_id: session.user.id }))); await supabase.from('viagens').update({ checklist_seed: true }).eq('id', viagem.id); await carregar(); }

  // define o nome escolhido pela pessoa (tela de boas-vindas ou Minha Conta)
  async function definirMeuNome(nome) {
    const nm = (nome || '').trim();
    if (!nm) return { erro: 'Informe um nome.' };
    const { error } = await supabase.auth.updateUser({ data: { nome: nm } });
    if (error) return { erro: 'Não consegui salvar o nome.' };
    if (perfil) await supabase.from('perfis').update({ nome: nm, nome_definido: true }).eq('id', perfil.id);
    setPrecisaNome(false);
    await carregar();
    return { ok: true };
  }

  async function definirMeta(valor) {
    if (!perfil) return;
    const v = (valor === '' || valor == null || isNaN(valor)) ? null : Number(valor);
    await supabase.from('perfis').update({ meta_valor: v }).eq('id', perfil.id);
    await carregar();
  }
  async function adicionarGuardado(banco, valor) {
    const b = (banco || '').trim(); const v = Number(valor);
    if (!b || !(v > 0) || !viagem) return;
    await supabase.from('guardados').insert({ viagem_id: viagem.id, user_id: session.user.id, banco: b, valor: v });
    await carregar();
  }
  async function removerGuardado(id) {
    await supabase.from('guardados').delete().eq('id', id);
    await carregar();
  }

  async function adicionarLugar({ nome, endereco, comentario, prioridade, categoria }) {
    const n = (nome || '').trim();
    if (!n || !viagem) return;
    await supabase.from('lugares').insert({ viagem_id: viagem.id, nome: n, endereco: (endereco || '').trim() || null, comentario: (comentario || '').trim() || null, prioridade: prioridade || 'sugerido', categoria: categoria || 'outro' });
    await carregar();
  }
  async function editarLugar(id, campos) { await supabase.from('lugares').update(campos).eq('id', id); await carregar(); }
  async function removerLugar(id) { await supabase.from('lugares').delete().eq('id', id); await carregar(); }

  // ----- Passagem aérea (compartilhada com a viagem) -----
  const CAMPOS_PASSAGEM = ['sentido', 'companhia', 'telefone', 'origem', 'destino', 'data', 'hora', 'hora_chegada', 'data_chegada', 'voo', 'localizador', 'pedido', 'passageiros', 'assentos', 'obs'];
  function limparPassagem(c) {
    const out = {};
    for (const k of CAMPOS_PASSAGEM) {
      if (!(k in c)) continue;
      const v = typeof c[k] === 'string' ? c[k].trim() : c[k];
      out[k] = v === '' ? null : v;
    }
    if (out.sentido == null) delete out.sentido;
    return out;
  }
  async function adicionarPassagem(campos) {
    const { error } = await supabase.from('passagens').insert({ viagem_id: viagem.id, user_id: session.user.id, ...limparPassagem(campos) });
    if (error) return { erro: 'Não consegui salvar a passagem. Confere a internet e tenta de novo.' };
    await carregar();
    return { ok: true };
  }
  async function editarPassagem(id, campos) {
    const { error } = await supabase.from('passagens').update(limparPassagem(campos)).eq('id', id);
    if (error) return { erro: 'Não consegui salvar a alteração.' };
    await carregar();
    return { ok: true };
  }
  async function removerPassagem(id) { await supabase.from('passagens').delete().eq('id', id); await carregar(); }

  // ----- Documentos da viagem: um documento = pasta com N arquivos (bucket privado "documentos") -----
  const extDe = (mime) => (mime === 'application/pdf' ? 'pdf' : mime === 'image/png' ? 'png' : 'jpg');
  async function subirArquivosDoc(docId, arquivos) {
    // arquivos: [{ file, mime, nome }]. Sobe um a um; devolve quantos falharam.
    // ordem = posição na lista (número pequeno). Antes era Date.now() e estourava o
    // limite do campo — o arquivo subia e era apagado em seguida.
    let falhas = 0, ordem = Math.floor(Date.now() / 1000) % 1000000000;
    for (const a of arquivos || []) {
      if (!a || !a.file) continue;
      const path = `${viagem.id}/${docId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${extDe(a.mime)}`;
      const { error: e1 } = await supabase.storage.from('documentos').upload(path, a.file, { contentType: a.mime || 'application/octet-stream', upsert: false });
      if (e1) { falhas++; continue; }
      const { error: e2 } = await supabase.from('documento_arquivos').insert({ documento_id: docId, viagem_id: viagem.id, nome: a.nome || null, arquivo: path, mime: a.mime || null, tamanho: a.file.size || null, ordem: ordem++ });
      if (e2) { await supabase.storage.from('documentos').remove([path]); falhas++; }
    }
    return falhas;
  }
  async function adicionarDocumento({ titulo, categoria, obs, privado, arquivos }) {
    const t = (titulo || '').trim();
    if (!t) return { erro: 'Dá um nome pro documento.' };
    if (!arquivos || !arquivos.length) return { erro: 'Escolhe pelo menos um arquivo.' };
    const { data: doc, error } = await supabase.from('documentos').insert({ viagem_id: viagem.id, user_id: session.user.id, titulo: t, categoria: categoria || 'outros', obs: (obs || '').trim() || null, privado: !!privado }).select().single();
    if (error || !doc) return { erro: 'Não consegui criar o documento.' };
    const falhas = await subirArquivosDoc(doc.id, arquivos);
    await carregar();
    if (falhas === arquivos.length) { await supabase.from('documentos').delete().eq('id', doc.id); await carregar(); return { erro: 'Não consegui enviar os arquivos. Confere a internet (máx. 20 MB cada).' }; }
    return falhas ? { ok: true, aviso: `${falhas} arquivo(s) não subiram. Tenta adicionar de novo.` } : { ok: true };
  }
  async function adicionarArquivosDocumento(docId, arquivos) {
    const falhas = await subirArquivosDoc(docId, arquivos);
    await carregar();
    return falhas ? { erro: `${falhas} arquivo(s) não subiram. Tenta de novo.` } : { ok: true };
  }
  async function editarDocumento(id, campos) {
    const patch = {};
    if ('titulo' in campos) patch.titulo = (campos.titulo || '').trim();
    if ('categoria' in campos) patch.categoria = campos.categoria || 'outros';
    if ('obs' in campos) patch.obs = (campos.obs || '').trim() || null;
    if ('privado' in campos) patch.privado = !!campos.privado;
    const { error } = await supabase.from('documentos').update(patch).eq('id', id);
    if (error) return { erro: 'Não consegui salvar.' };
    await carregar();
    return { ok: true };
  }
  async function removerArquivoDocumento(arq) {
    await supabase.from('documento_arquivos').delete().eq('id', arq.id);
    if (arq.arquivo) await supabase.storage.from('documentos').remove([arq.arquivo]);
    await carregar();
  }
  async function removerDocumento(doc) {
    const paths = (doc.arquivos || []).map((a) => a.arquivo).filter(Boolean);
    if (doc.arquivo) paths.push(doc.arquivo);
    await supabase.from('documentos').delete().eq('id', doc.id); // documento_arquivos cai em cascata
    if (paths.length) await supabase.storage.from('documentos').remove(paths);
    await carregar();
  }
  // ----- Reservas de RV Park (Motorhome) — o comprovante vira um Documento (tipo Motorhome) -----
  const CAMPOS_RV = ['nome', 'checkin', 'checkout', 'endereco', 'telefone', 'confirmacao', 'valor', 'moeda', 'status', 'obs'];
  function limparRv(c) {
    const out = {};
    for (const k of CAMPOS_RV) {
      if (!(k in c)) continue;
      let v = typeof c[k] === 'string' ? c[k].trim() : c[k];
      if (k === 'valor') { v = (v === '' || v == null) ? null : Number(String(v).replace(',', '.')); if (isNaN(v)) v = null; }
      out[k] = v === '' ? null : v;
    }
    if (out.moeda && out.moeda !== 'BRL') out.moeda = 'USD';
    return out;
  }
  const tituloDocRv = (r) => `RV Park · ${r.nome || 'reserva'}${r.checkin ? ' · ' + String(r.checkin).slice(0, 10) : ''}`;
  async function garantirDocumentoRv(reserva) {
    if (reserva.documento_id) return reserva.documento_id;
    const { data: doc, error } = await supabase.from('documentos').insert({ viagem_id: viagem.id, user_id: session.user.id, titulo: tituloDocRv(reserva), categoria: 'motorhome', privado: false }).select().single();
    if (error || !doc) return null;
    await supabase.from('reservas_rv').update({ documento_id: doc.id }).eq('id', reserva.id);
    return doc.id;
  }
  async function adicionarReservaRv(campos, arquivos) {
    const c = limparRv(campos);
    if (!c.nome) return { erro: 'Dá um nome pro RV park.' };
    const { data: r, error } = await supabase.from('reservas_rv').insert({ viagem_id: viagem.id, user_id: session.user.id, ...c }).select().single();
    if (error || !r) return { erro: 'Não consegui salvar a reserva.' };
    let aviso = null;
    if (arquivos && arquivos.length) {
      const docId = await garantirDocumentoRv(r);
      if (docId) { const falhas = await subirArquivosDoc(docId, arquivos); if (falhas) aviso = `${falhas} arquivo(s) não subiram.`; }
      else aviso = 'Reserva salva, mas não consegui anexar o documento.';
    }
    await carregar();
    return { ok: true, aviso };
  }
  async function editarReservaRv(id, campos, arquivos) {
    const c = limparRv(campos);
    const { error } = await supabase.from('reservas_rv').update(c).eq('id', id);
    if (error) return { erro: 'Não consegui salvar a alteração.' };
    let aviso = null;
    const atual = (reservasRv || []).find((x) => x.id === id) || { id };
    const merged = { ...atual, ...c };
    if (arquivos && arquivos.length) {
      const docId = await garantirDocumentoRv(merged);
      if (docId) { const falhas = await subirArquivosDoc(docId, arquivos); if (falhas) aviso = `${falhas} arquivo(s) não subiram.`; }
      else aviso = 'Alteração salva, mas não consegui anexar o documento.';
    }
    if (merged.documento_id) await supabase.from('documentos').update({ titulo: tituloDocRv(merged) }).eq('id', merged.documento_id);
    await carregar();
    return { ok: true, aviso };
  }
  async function removerReservaRv(r) {
    // leva junto o que foi criado a partir dela (gasto lançado e parada do roteiro)
    if (r.gasto_id) {
      await supabase.from('gasto_divisao').delete().eq('gasto_id', r.gasto_id);
      await supabase.from('gastos').delete().eq('id', r.gasto_id);
    }
    if (r.ponto_id) await supabase.from('pontos_roteiro').delete().eq('id', r.ponto_id);
    await supabase.from('reservas_rv').delete().eq('id', r.id);
    if (r.documento_id) {
      const doc = (documentos || []).find((d) => d.id === r.documento_id);
      if (doc) await removerDocumento(doc); else await supabase.from('documentos').delete().eq('id', r.documento_id);
    }
    await carregar();
  }

  // ----- Reserva de RV park: vira parada no roteiro e/ou gasto lançado -----
  // Guardamos ponto_id e gasto_id na própria reserva pra não duplicar quando a
  // pessoa salvar de novo, e pra conseguir atualizar/apagar junto.

  // Cria (ou atualiza) a parada do roteiro no dia do check-in.
  async function reservaParaRoteiro(reserva) {
    if (!viagem || !reserva) return { erro: 'Reserva inválida.' };
    if (!reserva.checkin) return { erro: 'Preencha o check-in pra colocar no roteiro.' };
    const nota = [reserva.confirmacao ? `Reserva ${reserva.confirmacao}` : '', reserva.telefone ? `Tel ${reserva.telefone}` : '', reserva.obs || ''].filter(Boolean).join(' · ') || null;
    const campos = {
      nome: reserva.nome, endereco: reserva.endereco || null, local: reserva.endereco || null,
      nota, data_inicio: reserva.checkin, tipo: 'hospedagem',
      status: reserva.status === 'pago' || reserva.status === 'reservado' ? 'Confirmado' : 'A definir',
    };
    if (reserva.ponto_id && (pontos || []).some((p) => p.id === reserva.ponto_id)) {
      await supabase.from('pontos_roteiro').update(campos).eq('id', reserva.ponto_id);
      await carregar();
      return { ok: true, atualizado: true };
    }
    const { data: novo, error } = await supabase.from('pontos_roteiro').insert({ viagem_id: viagem.id, ordem: 999, ...campos }).select().single();
    if (error || !novo) return { erro: 'Não consegui colocar no roteiro.' };
    await supabase.from('reservas_rv').update({ ponto_id: novo.id }).eq('id', reserva.id);
    await carregar();
    return { ok: true };
  }
  async function tirarReservaDoRoteiro(reserva) {
    if (!reserva || !reserva.ponto_id) return;
    await supabase.from('pontos_roteiro').delete().eq('id', reserva.ponto_id);
    await supabase.from('reservas_rv').update({ ponto_id: null }).eq('id', reserva.id);
    await carregar();
  }

  // Lança (ou atualiza) o gasto da reserva. `participantes` = [{ id, partes }].
  async function reservaParaGasto(reserva, { pagoPor, participantes, categoria }) {
    if (!viagem || !reserva) return { erro: 'Reserva inválida.' };
    const valor = Number(reserva.valor);
    if (!(valor > 0)) return { erro: 'Preencha o valor da reserva.' };
    if (!pagoPor) return { erro: 'Escolha quem pagou.' };
    const gente = (participantes || []).filter((p) => p && p.id);
    if (!gente.length) return { erro: 'Marque pelo menos uma pessoa na divisão.' };
    const campos = {
      descricao: `RV Park · ${reserva.nome}`,
      valor, moeda: reserva.moeda === 'BRL' ? 'BRL' : 'USD',
      categoria: categoria || 'camping', pago_por: pagoPor,
      data: reserva.checkin || hojeLocal(),
      ponto_id: reserva.ponto_id || null,
    };
    const jaExiste = reserva.gasto_id && (gastos || []).some((g) => g.id === reserva.gasto_id);
    let gastoId = reserva.gasto_id;
    if (jaExiste) {
      const { error } = await supabase.from('gastos').update(campos).eq('id', gastoId);
      if (error) return { erro: 'Não consegui atualizar o gasto.' };
    } else {
      const { data: novo, error } = await supabase.from('gastos').insert({ viagem_id: viagem.id, user_id: session.user.id, privado: false, ...campos }).select().single();
      if (error || !novo) return { erro: 'Não consegui lançar o gasto.' };
      gastoId = novo.id;
      await supabase.from('reservas_rv').update({ gasto_id: gastoId }).eq('id', reserva.id);
    }
    await supabase.from('gasto_divisao').delete().eq('gasto_id', gastoId);
    await supabase.from('gasto_divisao').insert(gente.map((p) => ({ gasto_id: gastoId, perfil_id: p.id, partes: p.partes || 1 })));
    await carregar();
    return { ok: true, atualizado: jaExiste };
  }
  // Desfaz o lançamento (apaga o gasto e a divisão). Usado quando a pessoa
  // desliga "lançar nos gastos" ou tira o status Pago.
  async function tirarGastoDaReserva(reserva) {
    if (!reserva || !reserva.gasto_id) return;
    await supabase.from('gasto_divisao').delete().eq('gasto_id', reserva.gasto_id);
    await supabase.from('gastos').delete().eq('id', reserva.gasto_id);
    await supabase.from('reservas_rv').update({ gasto_id: null }).eq('id', reserva.id);
    await carregar();
  }

  // ----- Logins dos apps da viagem -----
  // A senha vai em texto no banco; o que protege é o RLS (só membros da viagem,
  // e item privado só o dono) — ver supabase/migracao-logins.sql. Por isso a tela
  // avisa pra não usar isso com banco, cartão e e-mail principal.
  async function adicionarLoginApp({ app, usuario, senha, url, obs, privado }) {
    const { error } = await supabase.from('logins_app').insert({
      viagem_id: viagem.id, app: (app || '').trim(), usuario: (usuario || '').trim() || null,
      senha: senha || null, url: (url || '').trim() || null, obs: (obs || '').trim() || null,
      privado: privado !== false, user_id: session.user.id,
    });
    if (error) throw error;
    await carregar();
  }
  async function editarLoginApp(id, campos) {
    const { error } = await supabase.from('logins_app').update(campos).eq('id', id);
    if (error) throw error;
    await carregar();
  }
  async function removerLoginApp(id) { await supabase.from('logins_app').delete().eq('id', id); await carregar(); }

  // link assinado (1 h) pra abrir/baixar um arquivo — o bucket é privado
  async function urlArquivoDocumento(arq, baixar) {
    if (!arq || !arq.arquivo) return null;
    const nome = (arq.nome || 'documento').replace(/[\\/:*?"<>|]+/g, '-');
    const opts = baixar ? { download: nome } : undefined;
    const { data } = await supabase.storage.from('documentos').createSignedUrl(arq.arquivo, 3600, opts);
    return (data && data.signedUrl) || null;
  }

  async function lugarParaRoteiro(lugar, data, hora) {
    if (!viagem || !lugar) return;
    await supabase.from('pontos_roteiro').insert({ viagem_id: viagem.id, nome: lugar.nome, endereco: lugar.endereco || null, local: lugar.endereco || null, nota: lugar.comentario || null, data_inicio: data || null, hora: hora || null, tipo: 'passeio', ordem: 999 });
    await supabase.from('lugares').update({ no_roteiro: true }).eq('id', lugar.id);
    await carregar();
  }

  async function adicionarApp({ nome, funcao, beneficio }) {
    const n = (nome || '').trim();
    if (!n || !viagem) return;
    await supabase.from('apps_instalar').insert({ viagem_id: viagem.id, nome: n, funcao: (funcao || '').trim() || null, beneficio: (beneficio || '').trim() || null });
    await carregar();
  }
  async function removerApp(id) { await supabase.from('apps_instalar').delete().eq('id', id); await carregar(); }

  async function adicionarPergunta({ pergunta_pt, pergunta_en, resposta_pt, resposta_en }) {
    if (!viagem || !(pergunta_pt || '').trim()) return;
    const ordem = (perguntasImigracao || []).length;
    await supabase.from('perguntas_imigracao').insert({ viagem_id: viagem.id, pergunta_pt: pergunta_pt.trim(), pergunta_en: (pergunta_en || '').trim(), resposta_pt: (resposta_pt || '').trim() || null, resposta_en: (resposta_en || '').trim() || null, ordem });
    await carregar();
  }
  async function editarPergunta(id, campos) { await supabase.from('perguntas_imigracao').update(campos).eq('id', id); await carregar(); }
  async function removerPergunta(id) { await supabase.from('perguntas_imigracao').delete().eq('id', id); await carregar(); }

  async function alternarAppInstalado(appKey) {
    if (!viagem || !session) return;
    const jaMarcado = (appsMarcados || []).find((m) => m.app_key === appKey);
    if (jaMarcado) {
      await supabase.from('apps_marcados').delete().eq('id', jaMarcado.id);
    } else {
      await supabase.from('apps_marcados').insert({ viagem_id: viagem.id, user_id: session.user.id, app_key: appKey });
    }
    await carregar();
  }
  // Esconder/reexibir uma sugestão de app (a lista fixa em AppsInstalar.js, não os
  // apps adicionados à mão). Reaproveita a mesma tabela apps_marcados de
  // alternarAppInstalado, só com um prefixo diferente na chave — não precisa de
  // tabela nova, e fica por pessoa (cada um esconde só pra si).
  async function ocultarAppSugestao(appKey) {
    if (!viagem || !session) return;
    await supabase.from('apps_marcados').insert({ viagem_id: viagem.id, user_id: session.user.id, app_key: 'oculto:' + appKey });
    await carregar();
  }
  async function reexibirAppSugestao(appKey) {
    const m = (appsMarcados || []).find((x) => x.app_key === 'oculto:' + appKey);
    if (m) { await supabase.from('apps_marcados').delete().eq('id', m.id); await carregar(); }
  }

  // ===== Diário da viagem (texto, fotos, áudio, por dia) =====
  // Bucket 'diario' é público — guardamos só o caminho e resolvemos a URL na hora de mostrar.
  function urlDiario(path) {
    if (!path) return null;
    if (path.startsWith('http')) return path;
    const { data } = supabase.storage.from('diario').getPublicUrl(path);
    return (data && data.publicUrl) || null;
  }
  async function subirArquivoDiario(blob, ext) {
    const path = `${viagem.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { error } = await supabase.storage.from('diario').upload(path, blob, { contentType: blob.type || undefined, upsert: false });
    if (error) throw error;
    return path;
  }
  async function adicionarEntradaDiario({ data, texto, fotos, audioBlob, audioExt, audioDuracao, modo }) {
    if (!viagem || !perfil) return;
    const fotoPaths = [];
    if (fotos && fotos.length) { for (const f of fotos) fotoPaths.push(await subirArquivoDiario(f, 'jpg')); }
    let audioPath = null;
    if (audioBlob) audioPath = await subirArquivoDiario(audioBlob, audioExt || 'webm');
    const { error } = await supabase.from('diario_entradas').insert({
      viagem_id: viagem.id, perfil_id: perfil.id, user_id: session.user.id,
      data: data || hojeLocal(), texto: (texto || '').trim() || null,
      fotos: fotoPaths, audio_url: audioPath, audio_duracao: audioDuracao || null,
      modo: modo === 'individual' ? 'individual' : 'grupo',
    });
    if (error) throw error;
    await carregar();
  }
  async function removerEntradaDiario(entrada) {
    try {
      const paths = [...(entrada.fotos || [])];
      if (entrada.audio_url) paths.push(entrada.audio_url);
      if (paths.length) await supabase.storage.from('diario').remove(paths);
    } catch (e) { /* segue removendo o registro mesmo se a limpeza da mídia falhar */ }
    await supabase.from('diario_entradas').delete().eq('id', entrada.id);
    await carregar();
  }

  function trocarViagem(id) { if (typeof window !== 'undefined') window.localStorage.setItem('viagemAtiva', id); carregar(); }
  async function definirFotoViagem(id, url) { await supabase.from('viagens').update({ foto: url || null }).eq('id', id); await carregar(); }
  // Aceita string (compatibilidade antiga: só o nome) ou objeto com o perfil
  // completo da viagem, coletado no assistente de criação (ver NovaViagemWizard).
  async function criarViagem(dadosOuNome) {
    const uid = session.user.id;
    const dados = typeof dadosOuNome === 'string' ? { nome: dadosOuNome } : (dadosOuNome || {});
    const { nome, tipoViagem, destino, motivo, transporte, dataIda, dataVolta } = dados;
    const destinoLimpo = (destino || '').trim() || null;
    const { data: nv, error } = await supabase.from('viagens').insert({
      nome: (nome || 'Nova viagem').trim(), orcamento_brl: 0, cotacao_usd: 5.4, owner_id: uid,
      tipo_viagem: tipoViagem || null, destino: destinoLimpo, motivo: motivo || null,
      transporte: Array.isArray(transporte) ? transporte : [],
      data_ida: dataIda || null, data_volta: dataVolta || null,
    }).select().single();
    if (error) throw error;
    await supabase.from('viagem_membros').insert({ viagem_id: nv.id, user_id: uid, papel: 'dono' });
    if (typeof window !== 'undefined') window.localStorage.setItem('viagemAtiva', nv.id);
    // Viagem nacional com destino preenchido: tenta achar uma foto de capa da
    // cidade (best-effort — se não achar ou der erro, a viagem fica sem foto,
    // igual antes; o usuário sempre pode colar uma foto manualmente depois).
    if (tipoViagem === 'nacional' && destinoLimpo) {
      buscarFotoCidade(destinoLimpo).then((url) => {
        if (url) supabase.from('viagens').update({ foto: url }).eq('id', nv.id).then(() => carregar());
      });
    }
    await carregar();
    return nv;
  }
  async function gerarConvite(viagemId) {
    const codigo = Math.random().toString(36).slice(2, 8).toUpperCase();
    const { error } = await supabase.from('convites').insert({ viagem_id: viagemId || viagem.id, codigo, criado_por: session.user.id });
    if (error) return null;
    return codigo;
  }
  async function entrarPorConvite(codigo) {
    const cod = (codigo || '').trim().toUpperCase();
    if (!cod) return { erro: 'Informe o código.' };
    const { data: c } = await supabase.from('convites').select('*').eq('codigo', cod).eq('ativo', true).maybeSingle();
    if (!c) return { erro: 'Convite inválido ou expirado.' };
    await supabase.from('viagem_membros').upsert({ viagem_id: c.viagem_id, user_id: session.user.id, papel: 'membro' }, { onConflict: 'viagem_id,user_id' });
    if (typeof window !== 'undefined') window.localStorage.setItem('viagemAtiva', c.viagem_id);
    await carregar();
    return { ok: true };
  }
  async function apagarViagem(id) {
    const alvo = (viagens || []).find((v) => v.id === id);
    if (!alvo) return { erro: 'Viagem não encontrada.' };
    if (alvo.owner_id !== session.user.id) return { erro: 'Só o dono pode apagar esta viagem.' };
    try {
      const { data: gs } = await supabase.from('gastos').select('id').eq('viagem_id', id);
      const gids = (gs || []).map((g) => g.id);
      if (gids.length) await supabase.from('gasto_divisao').delete().in('gasto_id', gids);
      await supabase.from('gastos').delete().eq('viagem_id', id);
      await supabase.from('pontos_roteiro').delete().eq('viagem_id', id);
      await supabase.from('acertos').delete().eq('viagem_id', id);
      await supabase.from('registros_km').delete().eq('viagem_id', id);
      await supabase.from('checklist_itens').delete().eq('viagem_id', id);
      await supabase.from('passagens').delete().eq('viagem_id', id);
      await supabase.from('convites').delete().eq('viagem_id', id);
      await supabase.from('viagem_membros').delete().eq('viagem_id', id);
      const { error } = await supabase.from('viagens').delete().eq('id', id);
      if (error) return { erro: 'Não consegui apagar a viagem.' };
    } catch (e) { return { erro: 'Não consegui apagar a viagem.' }; }
    if (typeof window !== 'undefined' && window.localStorage.getItem('viagemAtiva') === id) window.localStorage.removeItem('viagemAtiva');
    await carregar();
    return { ok: true };
  }

  const value = { perfil, viagem, viagens, trocarViagem, criarViagem, gerarConvite, entrarPorConvite, apagarViagem, definirFotoViagem, perfis, pontos, gastos, divisoes, gastoVistoPor, acertos, carregando, gastoEditando, setGastoEditando, salvarGasto, atualizarGasto, registrarAcerto, removerAcerto, adicionarPessoa, atualizarNomePessoa, removerPessoa, atualizarCotacao, atualizarOrcamento, removerGasto, registrosKm, adicionarKm, removerKm, checklist, adicionarChecklist, alternarChecklist, editarChecklist, removerChecklist, semearChecklist, definirValorCompra, definirValorItem, guardados, definirMeta, adicionarGuardado, removerGuardado, lugares, adicionarLugar, editarLugar, removerLugar, lugarParaRoteiro, passagens, adicionarPassagem, editarPassagem, removerPassagem, documentos, adicionarDocumento, adicionarArquivosDocumento, editarDocumento, removerDocumento, removerArquivoDocumento, urlArquivoDocumento, reservasRv, adicionarReservaRv, editarReservaRv, removerReservaRv, reservaParaRoteiro, tirarReservaDoRoteiro, reservaParaGasto, tirarGastoDaReserva, loginsApp, adicionarLoginApp, editarLoginApp, removerLoginApp, appsInstalar, adicionarApp, removerApp, perguntasImigracao, adicionarPergunta, editarPergunta, removerPergunta, appsMarcados, alternarAppInstalado, ocultarAppSugestao, reexibirAppSugestao, urlRecibo, erro, recarregar: carregar, precisaNome, definirMeuNome, diario, adicionarEntradaDiario, removerEntradaDiario, urlDiario };
  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}
function corAleatoria() { const cores = ['#534AB7', '#D4537E', '#0F6E56', '#BA7517', '#185FA5', '#993C1D']; return cores[Math.floor(Math.random() * cores.length)]; }
